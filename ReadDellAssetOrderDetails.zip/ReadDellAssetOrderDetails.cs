///<remarks>
///     Remarks:            This class leverages the public accessible Dell API to get the original Order and       
///                         Configuration related details pertaining to a Dell system. It includes the attribute 
///                         'SQLFunction' as the assembly is intended to be imported in to a CLR Integration Enabled 
///                         instance of MSSQL Server and a requirement when returning either a scalar value or 
///                         table.
///                   
///                         The Dell API to my understanding/observation does not return warranty details for systems
///                         which had their warranty extended.
///     Version:            1.0.0
///     Date:               01/07/2013
/// </remarks>

using Microsoft.SqlServer.Server;
using System;
using System.Data.SqlTypes;
using System.IO;
using System.Net;
using System.Xml;
public class UserDefinedFunctions
{
	protected static readonly string _apiKey = "1adecee8a60444738f280aad1cd87d0e";
	private string _uri = null;
	private XmlTextReader _xmlTextReader = null;
	private HttpWebRequest _request = null;
	private HttpWebResponse _webResponse = null;
	private Stream _responseStream = null;
	[SqlFunction]
	public SqlXml DellWebAPI(SqlString Tag)
	{
		this._uri = string.Format("https://api.dell.com/support/v2/assetinfo/warranty/tags?svctags={0}&apikey={1}", Tag, UserDefinedFunctions._apiKey);
		SqlXml result;
		try
		{
			this._request = (HttpWebRequest)WebRequest.Create(this._uri);
			this._webResponse = (HttpWebResponse)this._request.GetResponse();
			this._responseStream = this._webResponse.GetResponseStream();
			this._xmlTextReader = new XmlTextReader(this._responseStream);
			result = new SqlXml(this._xmlTextReader);
		}
		catch (Exception)
		{
			throw;
		}
		finally
		{
			this._uri = null;
			this._xmlTextReader = null;
			this._request = null;
			this._webResponse = null;
			this._responseStream = null;
		}
		return result;
	}
}